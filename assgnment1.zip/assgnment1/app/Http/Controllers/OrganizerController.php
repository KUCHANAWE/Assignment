<?php

namespace App\Http\Controllers;

use App\Models\Organizer;
use Illuminate\Http\Request;

class OrganizerController extends Controller
{
    /**
     * Display a listing of the organizers.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Mendapatkan semua organizer
        $organizers = Organizer::all();
        return view('organizers.index', compact('organizers'));
    }

    /**
     * Show the form for creating a new organizer.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Menampilkan form untuk membuat organizer baru
        return view('organizers.create');
    }

    /**
     * Store a newly created organizer in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validasi data yang masuk
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'facebook_link' => 'nullable|url',
            'x_link' => 'nullable|url',
            'website_link' => 'nullable|url',
            'active' => 'required|boolean',
        ]);

        // Simpan organizer baru ke database
        Organizer::create($request->all());

        return redirect()->route('organizers.index')
                         ->with('success', 'Organizer created successfully.');
    }

    /**
     * Display the specified organizer.
     *
     * @param  \App\Models\Organizer  $organizer
     * @return \Illuminate\Http\Response
     */
    public function show(Organizer $organizer)
    {
        // Menampilkan detail organizer
        return view('organizers.show', compact('organizer'));
    }

    /**
     * Show the form for editing the specified organizer.
     *
     * @param  \App\Models\Organizer  $organizer
     * @return \Illuminate\Http\Response
     */
    public function edit(Organizer $organizer)
    {
        // Menampilkan form untuk mengedit organizer
        return view('organizers.edit', compact('organizer'));
    }

    /**
     * Update the specified organizer in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Organizer  $organizer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Organizer $organizer)
    {
        // Validasi data yang masuk
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'facebook_link' => 'nullable|url',
            'x_link' => 'nullable|url',
            'website_link' => 'nullable|url',
            'active' => 'required|boolean',
        ]);

        // Update organizer yang ada
        $organizer->update($request->all());

        return redirect()->route('organizers.index')
                         ->with('success', 'Organizer updated successfully.');
    }

    /**
     * Remove the specified organizer from the database.
     *
     * @param  \App\Models\Organizer  $organizer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Organizer $organizer)
    {
        // Hapus organizer dari database
        $organizer->delete();

        return redirect()->route('organizers.index')
                         ->with('success', 'Organizer deleted successfully.');
    }
}

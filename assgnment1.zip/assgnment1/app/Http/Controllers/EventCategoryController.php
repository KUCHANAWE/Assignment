<?php

namespace App\Http\Controllers;

use App\Models\EventCategory;
use Illuminate\Http\Request;

class EventCategoryController extends Controller
{
    /**
     * Display a listing of the event categories.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = EventCategory::all();
        return view('event_categories.index', compact('categories'));
    }

    /**
     * Show the form for creating a new event category.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('event_categories.create');
    }

    /**
     * Store a newly created event category in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'active' => 'required|boolean',
        ]);

        EventCategory::create($request->all());

        return redirect()->route('event_categories.index')
                         ->with('success', 'Event category created successfully.');
    }

    /**
     * Show the form for editing the specified event category.
     *
     * @param  \App\Models\EventCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(EventCategory $category)
    {
        return view('event_categories.edit', compact('category'));
    }

    /**
     * Update the specified event category in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EventCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EventCategory $category)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'active' => 'required|boolean',
        ]);

        $category->update($request->all());

        return redirect()->route('event_categories.index')
                         ->with('success', 'Event category updated successfully.');
    }

    /**
     * Remove the specified event category from the database.
     *
     * @param  \App\Models\EventCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(EventCategory $category)
    {
        $category->delete();

        return redirect()->route('event_categories.index')
                         ->with('success', 'Event category deleted successfully.');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\EventCategory;
use App\Models\Organizer;
use Illuminate\Http\Request;

class MasterEventController extends Controller
{
    /**
     * Display a listing of the events (Master Event).
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Mengambil semua event dengan relasi organizer dan kategori event
        $events = Event::with(['organizer', 'eventCategory'])->get();
        return view('events.index', compact('events'));
    }

    /**
     * Show the form for creating a new event.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Mengambil semua kategori event dan organizer untuk dropdown
        $categories = EventCategory::all();
        $organizers = Organizer::all();
        return view('events.create', compact('categories', 'organizers'));
    }

    /**
     * Store a newly created event in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validasi inputan form
        $request->validate([
            'title' => 'required|string|max:255',
            'venue' => 'required|string|max:255',
            'date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'description' => 'nullable|string',
            'booking_url' => 'nullable|url',
            'tags' => 'nullable|string|max:255',
            'organizer_id' => 'required|exists:organizers,id',
            'event_category_id' => 'required|exists:event_categories,id',
            'active' => 'required|boolean',
        ]);

        // Menyimpan event baru ke database
        Event::create($request->all());

        return redirect()->route('events.index')
                         ->with('success', 'Event created successfully.');
    }

    /**
     * Show the form for editing the specified event.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(Event $event)
    {
        // Mengambil data kategori dan organizer untuk mengedit
        $categories = EventCategory::all();
        $organizers = Organizer::all();
        return view('events.edit', compact('event', 'categories', 'organizers'));
    }

    /**
     * Update the specified event in the database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Event $event)
    {
        // Validasi inputan form
        $request->validate([
            'title' => 'required|string|max:255',
            'venue' => 'required|string|max:255',
            'date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'description' => 'nullable|string',
            'booking_url' => 'nullable|url',
            'tags' => 'nullable|string|max:255',
            'organizer_id' => 'required|exists:organizers,id',
            'event_category_id' => 'required|exists:event_categories,id',
            'active' => 'required|boolean',
        ]);

        // Update event di database
        $event->update($request->all());

        return redirect()->route('events.index')
                         ->with('success', 'Event updated successfully.');
    }

    /**
     * Remove the specified event from the database.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy(Event $event)
    {
        // Hapus event dari database
        $event->delete();

        return redirect()->route('events.index')
                         ->with('success', 'Event deleted successfully.');
    }
}

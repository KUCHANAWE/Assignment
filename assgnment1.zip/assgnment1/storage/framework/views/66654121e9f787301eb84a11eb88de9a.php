<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Create Event</title>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto mt-8">
        <h1 class="text-2xl font-bold mb-4">Create Event</h1>
        <form action="<?php echo e(route('events.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="title" class="block text-gray-700">Title</label>
                <input type="text" name="title" class="border border-gray-300 p-2 w-full" required>
            </div>
            <div class="mb-4">
                <label for="venue" class="block text-gray-700">Venue</label>
                <input type="text" name="venue" class="border border-gray-300 p-2 w-full" required>
            </div>
            <div class="mb-4">
                <label for="date" class="block text-gray-700">Date</label>
                <input type="date" name="date" class="border border-gray-300 p-2 w-full" required>
            </div>
            <div class="mb-4">
                <label for="start_time" class="block text-gray-700">Start Time</label>
                <input type="time" name="start_time" class="border border-gray-300 p-2 w-full" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-gray-700">Description</label>
                <textarea name="description" class="border border-gray-300 p-2 w-full" required></textarea>
            </div>
            <div class="mb-4">
                <label for="booking_url" class="block text-gray-700">Booking URL</label>
                <input type="url" name="booking_url" class="border border-gray-300 p-2 w-full">
            </div>
            <div class="mb-4">
                <label for="tags" class="block text-gray-700">Tags (JSON)</label>
                <input type="text" name="tags" class="border border-gray-300 p-2 w-full">
            </div>
            <div class="mb-4">
                <label for="event_category_id" class="block text-gray-700">Event Category</label>
                <select name="event_category_id" class="border border-gray-300 p-2 w-full" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-4">
                <label for="active" class="block text-gray-700">Active</label>
                <input type="checkbox" name="active" value="1" checked>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Create Event</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\assgnment1\resources\views/events/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1 class="text-3xl mb-4">Upcoming Events in Surabaya</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>Venue</th>
                <th>Date</th>
                <th>Organizer</th>
                <th>Category</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($event->title); ?></td>
                    <td><?php echo e($event->venue); ?></td>
                    <td><?php echo e($event->date); ?></td>
                    <td><?php echo e($event->organizer->name); ?></td>
                    <td><?php echo e($event->category->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\assgnment1\resources\views/events/index.blade.php ENDPATH**/ ?>
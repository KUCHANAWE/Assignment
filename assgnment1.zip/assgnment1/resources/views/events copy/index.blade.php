@extends('layouts.app')

@section('content')
<div class="container my-5">
    <h1 class="text-3xl mb-4">Upcoming Events in Surabaya</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>Venue</th>
                <th>Date</th>
                <th>Organizer</th>
                <th>Category</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($events as $event)
                <tr>
                    <td>{{ $event->title }}</td>
                    <td>{{ $event->venue }}</td>
                    <td>{{ $event->date }}</td>
                    <td>{{ $event->organizer->name }}</td>
                    <td>{{ $event->category->name }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection

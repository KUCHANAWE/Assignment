<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\EventCategory;

class EventCategorySeeder extends Seeder
{
    public function run()
    {
        $categories = [
            ['name' => 'Expo', 'active' => true],
            ['name' => 'Concert', 'active' => true],
            ['name' => 'Conference', 'active' => true],
        ];

        foreach ($categories as $category) {
            EventCategory::create($category);
        }
    }
}

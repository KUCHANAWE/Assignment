<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('events')->insert([
            [
                'title' => 'Enhanced holistic paradigm',
                'venue' => 'Acme Corp',
                'date' => '2024-03-18',
                'start_time' => '14:25:36',
                'description' => 'An event focused on integrating holistic approaches to innovation.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Open-source tangible interface',
                'venue' => 'Globex Corporation',
                'date' => '2023-11-04',
                'start_time' => '10:10:15',
                'description' => 'An interactive event showcasing open-source technologies.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Synergistic grid-enabled architecture',
                'venue' => 'Initech',
                'date' => '2024-05-20',
                'start_time' => '09:00:00',
                'description' => 'A conference focusing on future-ready architectures and grid-enabled systems.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'User-centric dynamic synergy',
                'venue' => 'Hooli',
                'date' => '2024-02-15',
                'start_time' => '13:30:00',
                'description' => 'This event focuses on user-centered design and dynamic collaborations.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'title' => 'Next-gen evolving architecture',
                'venue' => 'Vehement Capital Partners',
                'date' => '2023-12-10',
                'start_time' => '16:45:00',
                'description' => 'An expo featuring next-generation evolving architectures in tech.',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}

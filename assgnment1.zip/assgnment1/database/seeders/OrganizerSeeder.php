<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OrganizerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('organizers')->insert([
            [
                'NAME' => 'Global Events Co.',
                'facebook_link' => 'facebook.com/globalevents',
                'x_link' => 'x.com/globalevents',
                'website_link' =>  'globalevents.com',
                'created_at' => now(),
            ],
            [
                'NAME' => 'Specializing in live concerts and shows.',
                'facebook_link' => ' facebook.com/premierproductions',
                'x_link' => ' x.com/premierproductions',
                'website_link' =>  'premierproductions.com',
                'created_at' => now(),
            ],
            [
               'NAME' => 'Premium service for high-profile events.',
                'facebook_link' => 'facebook.com/eliteevents',
                'x_link' => 'x.com/eliteevents',
                'website_link' =>  'eliteevents.com',
                'created_at' => now(),
            ],
            [
                'NAME' => 'Modern conferences and networking events.',
                'facebook_link' => 'facebook.com/nextgenconferences',
                'x_link' => 'x.com/nextgenconferences',
                'website_link' =>  'nextgenconferences.com',
                'created_at' => now(),
            ],
            [
                'NAME' => 'Innovative concert organization with top artists.',
                'facebook_link' => 'facebook.com/visionaryconcerts',
                'x_link' => 'x.com/visionaryconcerts',
                'website_link' =>  'visionaryconcerts.com',
                'created_at' => now(),
            ],
        ]);
    }
}

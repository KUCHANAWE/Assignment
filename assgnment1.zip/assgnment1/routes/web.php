<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventController;
use App\Http\Controllers\OrganizerController;
use App\Http\Controllers\EventCategoryController;
use App\Http\Controllers\MasterEventController;

// Halaman Utama
Route::get('/', function () {
    return view('index');
});

// Rute untuk Events
Route::get('/events', [EventController::class, 'index']);
Route::get('/events/{id}', [EventController::class, 'show'])->name('events.show');

// Rute untuk Organizer
Route::resource('organizers', OrganizerController::class);

// Rute untuk Event Categories
Route::resource('event_categories', EventCategoryController::class);

// Rute untuk Master Events
Route::resource('master_events', MasterEventController::class);
